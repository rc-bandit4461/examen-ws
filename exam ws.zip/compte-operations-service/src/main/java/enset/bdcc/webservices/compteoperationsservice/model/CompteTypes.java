package enset.bdcc.webservices.compteoperationsservice.model;

public class CompteTypes{
    public static String COURANT = "COURANT";
    public static String EPARGNE = "EPARGNE";
}

