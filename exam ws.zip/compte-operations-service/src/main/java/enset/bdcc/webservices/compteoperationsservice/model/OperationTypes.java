package enset.bdcc.webservices.compteoperationsservice.model;


public class OperationTypes {
    public static String DEBIT = "DEBIT";
    public static String CREDIT = "CREDIT";
    public static String VIREMENT_DEBIT = "VIREMENT_DEBIT";
    public static String VIREMENT_CREDIT = "VIREMENT_CREDIT";
}
