package enset.bdcc.webservices.compteoperationsservice.model;


public class OperationTypes {
    public static String DEBIT = "DEBIT";
    public static String CREDIT = "CREDIT";
}
