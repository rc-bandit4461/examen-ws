package enset.bdcc.webservices.compteoperationsservice.model;

public class CompteEtats {
    public static String ACTIVE = "ACTIVE";
    public static String SUSPENDED = "SUSPENDED";
}

