package enset.bdcc.webservices.compteoperationsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompteOperationsServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
